<?php

$bilangan = 19;

echo "Bilangan " . $bilangan . " adalah " . ($bilangan % 2 == 0 ? "genap" : "ganjil");